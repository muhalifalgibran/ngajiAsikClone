package id.alif.footbalmatchschedule.model

data class ResponseApiBadgeAway (val teams: List<AwayBadge>)