package id.alif.footbalmatchschedule.model

data class ResponseApiBadgeHome (val teams: List<HomeBadge>)