package id.alif.footbalmatchschedule.model

data class ResponseDetail(val events: List<DetailMatch>)