package id.alif.footbalmatchschedule.model

data class ResponseApi (
    val events: List<LastMatchTeam>)